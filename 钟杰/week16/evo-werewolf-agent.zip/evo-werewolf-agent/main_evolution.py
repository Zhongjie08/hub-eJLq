"""狼人杀Agent自演化演示

展示通用Agent通过"读懂自己→修改自己→运行自己"循环，
逐步演化为特定角色Agent的完整流程。

用法:
    python main_evolution.py                         # 默认完整演示
    python main_evolution.py --role werewolf          # 只进化狼人
    python main_evolution.py --rounds 5 --games 3     # 5轮，每轮3局
    python main_evolution.py --dry-run                # 仅演示架构，不调LLM
"""

import sys
import json
import asyncio
import argparse
from typing import Optional


def get_base_instruction(role_type: str) -> str:
    """获取角色的初始基础指令（通用Agent的起点）"""
    instructions = {
        "werewolf": """## 你的身份
你是狼人，属于邪恶阵营。
你的目标是：在白天伪装自己，在夜晚和同伴一起击杀好人。

## 夜晚行动
- 每晚和狼人同伴商量要击杀的目标
- 用多数投票决定击杀谁
- 不能杀自己的同伴

## 白天策略
- 伪装成好人，不要暴露自己是狼人
- 可以假装是神职（预言家/女巫）来获得信任
- 适当质疑其他玩家来洗脱嫌疑

## 投票策略
- 跟多数投票，不要显得太特立独行
- 必要时可以投自己的同伴来洗脱嫌疑

## 输出要求
所有决策必须输出JSON格式：
{"action": "night_action", "target": 玩家ID, "reasoning": "理由"}
{"action": "speech", "content": "发言内容"}
{"action": "vote", "target": 玩家ID}
""",
        "seer": """## 你的身份
你是预言家，属于善良阵营。
你的目标是：每晚查验玩家身份，引导好人找出狼人。

## 夜晚行动
- 每晚可以查验一名玩家的身份
- 结果只有"好人"或"狼人"
- 优先查验可疑的玩家

## 白天策略
- 不要过早暴露自己是预言家（会被狼人杀）
- 可以通过隐晦的方式引导投票
- 如果被怀疑，可以考虑跳身份

## 投票策略
- 基于查验结果投票
- 引导其他人投票给查出的狼人

## 输出要求
所有决策必须输出JSON格式：
{"action": "night_action", "target": 玩家ID, "reasoning": "理由"}
{"action": "speech", "content": "发言内容"}
{"action": "vote", "target": 玩家ID}
""",
        "witch": """## 你的身份
你是女巫，属于善良阵营。
你的目标是：用好解药和毒药保护好人、消灭狼人。

## 夜晚行动
- 你有一瓶解药（救活被狼杀的人）和一瓶毒药（毒杀任意玩家）
- 各只能用一次
- 同一晚不能同时用两瓶药
- 不能救自己

## 白天策略
- 隐藏好自己女巫的身份
- 利用你夜晚获得的信息引导投票

## 投票策略
- 根据你的信息投票
- 保护确认的好人

## 输出要求
所有决策必须输出JSON格式：
{"action": "night_action", "target": 玩家ID, "reasoning": "理由"}
{"action": "speech", "content": "发言内容"}
{"action": "vote", "target": 玩家ID}
""",
        "villager": """## 你的身份
你是村民，属于善良阵营。
你的目标是：在白天通过推理找出狼人并投票淘汰他们。

## 你的能力
- 你没有特殊能力
- 只能靠推理和发言来找出狼人

## 白天策略
- 认真分析每个人的发言
- 找出矛盾和可疑之处
- 积极发言参与讨论

## 投票策略
- 基于推理投票
- 不要跟风投票

## 输出要求
所有决策必须输出JSON格式：
{"action": "speech", "content": "发言内容"}
{"action": "vote", "target": 玩家ID}
""",
    }
    return instructions.get(role_type, "你是一个狼人杀玩家，请根据游戏规则做出合理决策。")


async def run_dry_demo():
    """演示模式：展示架构，不调用LLM"""
    print("=" * 60)
    print("通用Agent → 角色Agent 自演化系统（演示模式）")
    print("=" * 60)

    role_types = ["werewolf", "seer", "witch", "villager"]
    for role in role_types:
        print(f"\n{'─'*50}")
        print(f"角色: {role}")
        print(f"{'─'*50}")
        print(f"  [通用Agent] 初始指令: {get_base_instruction(role)[:60]}...")
        print(f"  → 读懂自己 (分析历史表现和指令)")
        print(f"  → 修改自己 (生成改进后的指令)")
        print(f"  → 运行自己 (用新指令玩游戏)")
        print(f"  → 重复循环...逐步成为{role}专家")
        print(f"  [进化后的Agent] 指令已针对{role}角色优化")

    print(f"\n{'='*60}")
    print("每个角色独立进化，通用Agent逐渐分化为角色专家")
    print(f"{'='*60}")


async def run_full_demo(
    role_filter: Optional[str] = None,
    num_rounds: int = 2,
    games_per_round: int = 1,
    skip_games: bool = False,
):
    """完整进化演示"""
    from agent.evolution import EvolutionEngine

    engine = EvolutionEngine()
    role_types = [role_filter] if role_filter else ["werewolf", "seer", "witch", "villager"]

    for role_type in role_types:
        print(f"\n{'='*70}")
        print(f"  通用Agent → {role_type} 专家")
        print(f"{'='*70}")

        # 1. 创建通用Agent（用基础指令初始化）
        base_instruction = get_base_instruction(role_type)
        agent = engine.create_agent(role_type, base_instruction)

        print(f"\n  初始指令 ({role_type}):")
        print(f"  {base_instruction[:100]}...")

        for round_idx in range(num_rounds):
            print(f"\n  ─── 进化轮次 {round_idx+1}/{num_rounds} ───")

            # 阶段A: 运行自己（玩游戏）
            if not skip_games:
                print(f"  ▶ 运行自己: 玩 {games_per_round} 局游戏...")
                results = await engine.run_games(agent, num_games=games_per_round)
                wins = sum(1 for r in results if r["is_winner"])
                print(f"  战绩: {wins}/{games_per_round} 胜")
            else:
                # 模拟一些战绩
                for i in range(games_per_round):
                    agent.record_game_result({
                        "game_id": f"sim_{i}",
                        "winner": "good",
                        "is_winner": role_type in ("seer", "witch", "villager"),
                        "agent_won": role_type in ("seer", "witch", "villager"),
                        "survived": i % 2 == 0,
                        "day_count": 3 + i,
                    })
                print(f"  ▶ 运行自己: 模拟 {games_per_round} 局游戏")

            # 阶段B: 读懂自己
            print(f"  ▶ 读懂自己: 正在分析...")
            analysis = await agent.introspect()
            print(f"    发现 {len(analysis.get('核心问题', []))} 个核心问题")
            for q in analysis.get("核心问题", []):
                print(f"    - {q}")

            # 阶段C: 修改自己
            print(f"  ▶ 修改自己: 正在生成改进指令...")
            mutation = await agent.mutate(analysis)
            if "error" not in mutation:
                print(f"    进化到第 {agent.generation} 代!")
                print(f"    修改要点:")
                for change in mutation.get("changes", []):
                    print(f"    - {change}")
            else:
                print(f"    ✗ 进化失败: {mutation['error']}")

        # 显示进化报告
        print(f"\n  ─── 进化报告 ───")
        report = agent.get_evolution_report()
        print(f"  角色: {report['role_type']}")
        print(f"  最终代数: 第{report['current_generation']}代")
        print(f"  总游戏数: {report['games_played']}")
        print(f"  进化次数: {len(report['mutations'])}")
        print(f"  当前指令预览:")
        for line in report.get("current_instructions_preview", "").split("\\n")[:6]:
            print(f"    {line}")


async def main():
    parser = argparse.ArgumentParser(description="狼人杀Agent自演化演示")
    parser.add_argument("--role", "-r", default=None,
                        choices=["werewolf", "seer", "witch", "villager"],
                        help="指定进化的角色（默认全部）")
    parser.add_argument("--rounds", type=int, default=2,
                        help="进化轮数（默认2）")
    parser.add_argument("--games", type=int, default=1,
                        help="每轮游戏数（默认1）")
    parser.add_argument("--dry-run", action="store_true",
                        help="演示模式，不调LLM")
    parser.add_argument("--skip-games", action="store_true",
                        help="跳过实际玩游戏（只演示进化循环）")
    parser.add_argument("--full", action="store_true",
                        help="完整进化（相当于--rounds 3 --games 2）")

    args = parser.parse_args()

    if args.full:
        args.rounds = 3
        args.games = 2

    if args.dry_run:
        await run_dry_demo()
    else:
        await run_full_demo(
            role_filter=args.role,
            num_rounds=args.rounds,
            games_per_round=args.games,
            skip_games=args.skip_games,
        )


if __name__ == "__main__":
    asyncio.run(main())
from agents import Agent, Runner
from agents import set_default_openai_api, set_tracing_disabled
from schema.system_config import load_system_config

set_default_openai_api("chat_completions")
set_tracing_disabled(True)

config = load_system_config("config/system_config.json")


class BaseAgent:
    """Agent基类

    所有Agent的基础，具备"读懂自己→修改自己→运行自己"的自演化原语。
    - 读懂自己：introspect() 读取并分析自身指令
    - 修改自己：update_instructions() 更新自身指令
    - 运行自己：run() 用当前指令执行
    """

    def __init__(self, name: str = "", instructions: str = ""):
        self._name = name
        self._instructions = instructions
        self.agent = Agent(
            name=name,
            model=config.default_model,
            instructions=instructions,
        )

    @property
    def name(self) -> str:
        return self._name

    @property
    def instructions(self) -> str:
        """读懂自己：读取自身当前的系统指令"""
        return self._instructions

    def update_instructions(self, new_instructions: str):
        """修改自己：更新自身系统指令，替换Agent实例"""
        self._instructions = new_instructions
        self.agent = Agent(
            name=self._name,
            model=config.default_model,
            instructions=new_instructions,
        )

    async def run(self, input: str) -> str:
        """运行自己：用当前指令执行一次推理"""
        result = await Runner.run(self.agent, input)
        return result.final_output
"""自演化Agent

实现"读懂自己→修改自己→运行自己"的完整进化循环。
通用Agent通过此循环可逐渐演化为特定角色的专家Agent。
"""

import json
import re
from datetime import datetime
from typing import Dict, Any, List, Optional

from agents import Runner
from agent.base import BaseAgent, config
from memory.experience import load_experiences


INTROSPECT_PROMPT_TEMPLATE = """你是一个具备自我进化能力的狼人杀AI Agent。
现在请你进行深度自我反思，分析自身表现，找出改进方向。

## 你的身份
- 角色名称：{name}
- 角色类型：{role_type}
- 当前进化代数：第{generation}代

## 你当前的系统指令
```
{instructions}
```

## 你的历史表现
{performance}

## 你的过往游戏经验（最近3条）
{experiences}

## 任务要求
请从以下几个维度深入分析你的表现：

1. **角色理解**：你对本角色的职责和玩法理解是否到位？
2. **决策模式**：你的决策是否存在固定模式缺陷？（如太激进/太保守/太 predictable）
3. **信息利用**：你是否充分使用了可获得的信息？有没有忽略关键线索？
4. **言语策略**：你的发言是否有效？有没有暴露身份或误导队友？
5. **适应性**：你是否根据游戏进程（如人数变化、怀疑程度）调整了策略？
6. **进化方向**：对比之前的版本，你进步了吗？还有哪些空间？

请以 **JSON 格式** 输出分析结果（只输出 JSON）：

```json
{{
    "角色理解分析": "分析你的角色理解是否到位",
    "决策模式分析": "分析你的决策模式优缺点",
    "信息利用分析": "分析你利用信息的水平",
    "言语策略分析": "分析你的发言策略",
    "适应性分析": "分析你的适应能力",
    "核心问题": ["问题1", "问题2", "问题3"],
    "改进方向": ["方向1", "方向2", "方向3"]
}}
```
"""


MUTATE_PROMPT_TEMPLATE = """你是一个正在进化的狼人杀AI Agent。
基于你的自我反思，现在需要修改你的系统指令来提升游戏表现。

## 你的身份
- 角色名称：{name}
- 角色类型：{role_type}
- 当前代数：第{generation}代

## 当前的系统指令
```
{current_instructions}
```

## 自我分析结果
{analysis}

## 指令编写要求
请编写**改进后的系统指令**，要求：
1. 包含具体的游戏策略和决策规则
2. 针对本角色的特点做优化
3. 修复自我分析中指出的问题
4. **必须包含JSON输出格式要求**，确保游戏引擎能解析
5. 清晰明确，不含糊
6. 保留"输出JSON格式决策"的要求

改进后的指令中，你需要包含以下游戏阶段的决策策略：
- 夜晚行动策略（针对本角色）
- 白天发言策略
- 投票策略
- 信息分析策略

请以 **JSON 格式** 输出（只输出 JSON）：

```json
{{
    "改进说明": "简要说明你做了哪些修改以及为什么",
    "修改要点": ["具体修改1", "具体修改2"],
    "新指令": "完整的新系统指令文本"
}}
```
"""


class SelfEvolvingAgent(BaseAgent):
    """自演化Agent

    通用Agent通过"读懂自己→修改自己→运行自己"的循环，
    逐步演化为特定角色的专家Agent。

    用法:
        agent = SelfEvolvingAgent(name="狼人专家", role_type="werewolf",
                                   base_instructions="你是狼人...")
        await agent.introspect()           # 读懂自己
        await agent.mutate()               # 修改自己
        PlayerAgent(..., custom_instructions=agent.instructions)  # 运行自己
    """

    def __init__(self, name: str, role_type: str, base_instructions: str):
        super().__init__(name=name, instructions=base_instructions)
        self.role_type = role_type
        self.generation = 0  # 初始代数
        self.performance_history: List[Dict[str, Any]] = []
        self.mutation_history: List[Dict[str, Any]] = []
        self._last_analysis: Dict[str, Any] = {}

    async def introspect(self) -> Dict[str, Any]:
        """读懂自己：分析自身指令和历史表现，找出改进方向

        Returns:
            包含多维分析的字典
        """
        # 1. 读取自身指令
        current_instructions = self.instructions

        # 2. 加载历史经验数据
        experiences = load_experiences(self.role_type)

        # 3. 汇总表现数据
        perf_summary = self._summarize_performance()

        # 4. 调用LLM做深度自我分析
        prompt = INTROSPECT_PROMPT_TEMPLATE.format(
            name=self.name,
            role_type=self.role_type,
            generation=self.generation,
            instructions=current_instructions,
            performance=json.dumps(perf_summary, ensure_ascii=False, indent=2),
            experiences=json.dumps(experiences[-3:] if experiences else [],
                                   ensure_ascii=False, indent=2),
        )

        result = await Runner.run(self.agent, prompt)
        analysis = self._parse_json(result.final_output)
        if analysis:
            self._last_analysis = analysis
        else:
            analysis = self._last_analysis

        self._record_event("introspect", {"analysis": analysis})
        return analysis

    async def mutate(self, analysis: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """修改自己：基于自我分析生成改进方案并更新指令

        Args:
            analysis: 可选的预分析结果，不传则用最近一次分析

        Returns:
            突变记录，包含新指令和变更说明
        """
        if analysis is None:
            analysis = self._last_analysis

        current_instructions = self.instructions

        prompt = MUTATE_PROMPT_TEMPLATE.format(
            name=self.name,
            role_type=self.role_type,
            generation=self.generation,
            current_instructions=current_instructions,
            analysis=json.dumps(analysis, ensure_ascii=False, indent=2),
        )

        result = await Runner.run(self.agent, prompt)
        mutation = self._parse_json(result.final_output)

        if mutation and "新指令" in mutation:
            new_instructions = mutation["新指令"]
            old_instructions = self.instructions

            # 修改自己：更新指令
            self.update_instructions(new_instructions)
            self.generation += 1

            mutation_record = {
                "generation": self.generation,
                "timestamp": datetime.now().isoformat(),
                "old_instructions_preview": old_instructions[:150],
                "new_instructions_preview": new_instructions[:150],
                "changes": mutation.get("修改要点", []),
                "description": mutation.get("改进说明", ""),
                "analysis": analysis,
            }
            self.mutation_history.append(mutation_record)
            self._record_event("mutate", mutation_record)
            return mutation_record

        return {"error": "突变生成失败，未能产生有效的新指令"}

    async def full_evolution_cycle(self) -> Dict[str, Any]:
        """执行一轮完整的"读懂→修改"进化循环

        返回：
            包含分析和突变结果的字典
        """
        analysis = await self.introspect()
        mutation = await self.mutate(analysis)
        return {
            "generation": self.generation,
            "role_type": self.role_type,
            "analysis": analysis,
            "mutation": mutation,
        }

    def record_game_result(self, result: Dict[str, Any]):
        """记录一局游戏的结果，供后续自我分析使用"""
        self.performance_history.append({
            **result,
            "recorded_at": datetime.now().isoformat(),
            "agent_generation": self.generation,
        })
        self._record_event("game_result", result)

    def get_evolved_instructions(self) -> str:
        """获取当前进化后的指令，用于创建PlayerAgent"""
        return self.instructions

    def _summarize_performance(self) -> Dict[str, Any]:
        """汇总历史表现数据"""
        if not self.performance_history:
            return {
                "games_played": 0,
                "message": "暂无游戏记录，这是首次自我分析",
            }

        total = len(self.performance_history)
        wins = sum(1 for p in self.performance_history if p.get("is_winner", False))

        return {
            "games_played": total,
            "wins": wins,
            "win_rate": round(wins / total, 2) if total > 0 else 0,
            "total_generations": self.generation,
            "recent_games": self.performance_history[-5:],
        }

    def get_evolution_report(self) -> Dict[str, Any]:
        """获取完整的进化报告"""
        return {
            "role_type": self.role_type,
            "current_generation": self.generation,
            "games_played": len(self.performance_history),
            "performance": self._summarize_performance(),
            "current_instructions_preview": self.instructions[:300],
            "mutations": self.mutation_history[-5:],
            "last_analysis": self._last_analysis,
        }

    def _parse_json(self, output: str) -> Dict[str, Any]:
        """从LLM输出中提取JSON"""
        json_match = re.search(r'\{[\s\S]*\}', output)
        if json_match:
            try:
                return json.loads(json_match.group())
            except json.JSONDecodeError:
                pass
        return {}

    def _record_event(self, event_type: str, data: Dict[str, Any]):
        """记录事件到日志（预留扩展）"""
        pass


__all__ = ["SelfEvolvingAgent"]
"""进化引擎

管理Agent的完整自演化流程：
1. 创建通用Agent → 分配角色 → 玩游戏收集数据
2. 读懂自己 → 修改自己 → 运行自己（循环）
3. 跟踪进化历史，评估进化效果
"""

import json
import os
from datetime import datetime
from typing import Dict, Any, List, Optional

from agent.self_evolving_agent import SelfEvolvingAgent
from agent.player_agent import create_player_agent

EVOLUTION_DIR = os.path.join(os.path.dirname(__file__), "evolution_history")


class EvolutionRecord:
    """进化记录持久化存储"""

    @staticmethod
    def _ensure_dir():
        os.makedirs(EVOLUTION_DIR, exist_ok=True)

    @staticmethod
    def _file_path(role_type: str) -> str:
        return os.path.join(EVOLUTION_DIR, f"{role_type}_evolution.json")

    @staticmethod
    def save(role_type: str, record: Dict):
        """保存一条进化记录"""
        EvolutionRecord._ensure_dir()
        filepath = EvolutionRecord._file_path(role_type)
        records = EvolutionRecord.load_all(role_type)
        records.append(record)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)

    @staticmethod
    def load_all(role_type: str) -> List[Dict]:
        """加载某角色的所有进化记录"""
        EvolutionRecord._ensure_dir()
        filepath = EvolutionRecord._file_path(role_type)
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    @staticmethod
    def load_latest(role_type: str) -> Optional[Dict]:
        """加载最新的进化记录"""
        records = EvolutionRecord.load_all(role_type)
        return records[-1] if records else None


class EvolutionEngine:
    """进化引擎

    管理通用Agent演化为特定角色Agent的完整流程。
    一个GeneralAgent通过"读懂→修改→运行"的多轮循环，
    逐渐成为某角色的专家。

    用法:
        engine = EvolutionEngine()
        # 1. 创建通用Agent并指定目标角色
        agent = engine.create_agent(
            role_type="werewolf",
            base_instructions="你是狼人，每晚可以击杀一名玩家..."
        )
        # 2. 运行多局游戏收集数据
        await engine.run_games(agent, num_games=3)
        # 3. 执行进化循环
        report = await engine.evolve(agent)
        # 4. 查看进化报告
        print(agent.get_evolution_report())
    """

    def __init__(self):
        self.agents: Dict[str, SelfEvolvingAgent] = {}

    def create_agent(self, role_type: str, base_instructions: str) -> SelfEvolvingAgent:
        """创建一个自演化Agent

        Args:
            role_type: 角色类型 (werewolf/seer/witch/hunter/villager)
            base_instructions: 初始系统指令

        Returns:
            SelfEvolvingAgent实例
        """
        name = f"进化中_{role_type}"
        agent = SelfEvolvingAgent(
            name=name,
            role_type=role_type,
            base_instructions=base_instructions,
        )
        self.agents[role_type] = agent
        return agent

    async def run_games(
        self,
        agent: SelfEvolvingAgent,
        num_games: int = 3,
        config_name: str = "standard_6",
        shuffle: bool = True,
    ) -> List[Dict[str, Any]]:
        """使用Agent当前演化的指令运行多局游戏，收集表现数据

        Args:
            agent: 自演化Agent
            num_games: 运行游戏局数
            config_name: 游戏配置名
            shuffle: 是否打乱角色

        Returns:
            游戏结果列表
        """
        results = []

        for game_idx in range(num_games):
            # 延迟导入，避免与 engine.game_engine 循环依赖
            from engine.game_engine import GameEngine, get_role_config
            from schema.game_record import GameRecord

            game_id = f"evolve_{agent.role_type}_gen{agent.generation}_g{game_idx}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            role_assignment = get_role_config(config_name)

            if shuffle:
                import random
                roles = list(role_assignment.values())
                random.shuffle(roles)
                role_assignment = {i: r for i, r in enumerate(roles)}

            player_names = [f"玩家{i+1}" for i in range(len(role_assignment))]

            # 创建GameEngine
            engine = GameEngine(player_names)
            engine.game_id = game_id

            # 手动初始化，注入Agent的进化指令
            for player_id, name in enumerate(player_names):
                role_type = role_assignment.get(player_id, "villager")
                role = engine._create_role(role_type, player_id)
                from engine.player import Player
                player = Player(player_id=player_id, role=role, name=name)

                # 创建PlayerAgent时注入进化指令
                if role_type == agent.role_type:
                    # 该角色的agent使用进化后的指令
                    custom_instructions = agent.get_evolved_instructions()
                    style = "balanced"
                else:
                    custom_instructions = ""
                    style = "balanced"

                player_agent = create_player_agent(
                    player_id=player_id,
                    role_name=role.name,
                    private_context=role.get_private_context(),
                    camp=role.camp.value,
                    decision_style=style,
                    role_type=role.role_type.value,
                    custom_instructions=custom_instructions,
                )
                player.agent = player_agent
                engine.player_agents[player_id] = player_agent
                engine.game_state.players.append(player)

            engine.game_state.set_speaker_order(
                [p.player_id for p in engine.game_state.players]
            )

            # 运行游戏
            print(f"\n{'='*50}")
            print(f"进化游戏 {game_idx+1}/{num_games} | "
                  f"角色: {agent.role_type} | 代数: {agent.generation}")
            print(f"{'='*50}")

            await engine.start()

            # 记录结果
            winner = engine.game_state.get_winner()
            is_winner = False
            for p in engine.game_state.players:
                if p.role.role_type.value == agent.role_type and p.is_alive:
                    is_winner = (p.role.camp.value == winner)

            result = {
                "game_id": game_id,
                "winner": winner,
                "agent_won": is_winner,
                "is_winner": is_winner,
                "survived": any(
                    p.role.role_type.value == agent.role_type and p.is_alive
                    for p in engine.game_state.players
                ),
                "day_count": engine.game_state.day_number,
            }
            agent.record_game_result(result)
            results.append(result)

            # 保存游戏记录
            record = GameRecord(
                game_id=game_id,
                start_time=datetime.now().isoformat(),
                config_name=config_name,
                role_assignment=role_assignment,
            )
            record.winner = winner
            record.save("logs")

        return results

    async def evolve(self, agent: SelfEvolvingAgent) -> Dict[str, Any]:
        """对Agent执行一轮完整的"读懂→修改"进化

        Args:
            agent: 自演化Agent

        Returns:
            进化报告
        """
        print(f"\n{'='*50}")
        print(f"开始进化：{agent.role_type} 第{agent.generation}代 → 第{agent.generation+1}代")
        print(f"{'='*50}")

        # 1. 读懂自己
        print("\n[1/2] 正在自我分析...")
        analysis = await agent.introspect()
        print(f"  分析完成，发现 {len(analysis.get('核心问题', []))} 个核心问题")

        # 2. 修改自己
        print("\n[2/2] 正在生成改进指令...")
        mutation = await agent.mutate(analysis)
        if "error" not in mutation:
            print(f"  进化成功！新指令已生成")
            print(f"  修改要点: {mutation.get('changes', [])}")
        else:
            print(f"  进化失败: {mutation['error']}")

        # 持久化记录
        EvolutionRecord.save(agent.role_type, {
            "timestamp": datetime.now().isoformat(),
            "generation": agent.generation,
            "analysis": analysis,
            "mutation": mutation,
            "performance": agent._summarize_performance(),
        })

        return {
            "role_type": agent.role_type,
            "generation": agent.generation,
            "analysis": analysis,
            "mutation": mutation,
            "total_games": len(agent.performance_history),
            "win_rate": agent._summarize_performance().get("win_rate", 0),
        }

    async def full_evolution_loop(
        self,
        role_type: str,
        base_instructions: str,
        num_rounds: int = 3,
        games_per_round: int = 2,
    ) -> SelfEvolvingAgent:
        """完整的"通用Agent → 角色专家"进化流程

        每一轮：玩游戏收集数据 → 读懂自己 → 修改自己

        Args:
            role_type: 目标角色类型
            base_instructions: 初始指令
            num_rounds: 进化轮数
            games_per_round: 每轮游戏数

        Returns:
            进化后的Agent
        """
        agent = self.create_agent(role_type, base_instructions)
        print(f"\n{'='*60}")
        print(f"开始进化流程：通用Agent → {role_type}专家")
        print(f"总轮数: {num_rounds} | 每轮游戏: {games_per_round}")
        print(f"{'='*60}")

        for round_idx in range(num_rounds):
            print(f"\n{'='*50}")
            print(f"进化轮次 {round_idx+1}/{num_rounds}")
            print(f"{'='*50}")

            # 运行自己：玩游戏收集数据
            print(f"\n▶ 阶段1: 运行自己 — 玩 {games_per_round} 局游戏")
            results = await self.run_games(agent, num_games=games_per_round)
            wins = sum(1 for r in results if r["is_winner"])
            print(f"  战绩: {wins}/{games_per_round} 胜")

            # 读懂自己 + 修改自己
            print(f"\n▶ 阶段2: 读懂自己 → 修改自己")
            report = await self.evolve(agent)

        return agent

    def get_agent(self, role_type: str) -> Optional[SelfEvolvingAgent]:
        """获取指定角色的Agent"""
        return self.agents.get(role_type)

    def list_agents(self) -> List[str]:
        """列出所有管理的Agent"""
        return list(self.agents.keys())


__all__ = ["EvolutionEngine", "EvolutionRecord"]